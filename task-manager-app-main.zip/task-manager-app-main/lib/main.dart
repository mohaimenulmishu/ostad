import 'package:flutter/material.dart';
import 'package:task_manager_app/app.dart';

void main() {
  runApp(const TaskManagerApp());
}
