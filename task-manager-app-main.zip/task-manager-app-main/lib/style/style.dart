import 'dart:ui';
import 'package:flutter/material.dart';

class PrimaryColor {
  static Color color = const Color(0xFF21bf73);
}
