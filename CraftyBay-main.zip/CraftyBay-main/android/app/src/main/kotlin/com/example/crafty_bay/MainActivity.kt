package com.example.crafty_bay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
