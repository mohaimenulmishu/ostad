class AssetsPath {
  static const String imagePath = 'assets/images';
  static const String logo = '$imagePath/logos/logo.png';
  static const String logoNav = '$imagePath/logos/logo_nav.png';
  static const String dummyProductImage = '$imagePath/products/shoe.jpg';
}
