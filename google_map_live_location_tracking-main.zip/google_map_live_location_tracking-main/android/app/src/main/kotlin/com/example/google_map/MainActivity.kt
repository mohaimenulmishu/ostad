package com.example.google_map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
